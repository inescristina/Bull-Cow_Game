/* The game logic, no view code or direct user interaction
 This game is a simple guess the word game based on Mastermind
 */

//  FBullCowGame.hpp
//  BullCowGame
//
//  Created by Inês de Araújo Cristina on 31/10/2017.
//  Copyright © 2017 Inês Cristina. All rights reserved.
//
#pragma once

#ifndef FBullCowGame_hpp
#define FBullCowGame_hpp
#endif /* FBullCowGame_hpp */

#include <stdio.h>
#include <string>

// to make syntax Unreal friendly
using FString = std::string;
using int32 = int;

// all values initialised to zero
struct FBullCowCount
{
    int32 Bulls = 0;
    int32 Cows =0;
};

enum class EGuessStatus
{
    Invalid_Status,
    OK,
    Not_Isogram,
    Wrong_Length,
    Not_Lowercase
    
};

class FBullCowGame
{
public:
    FBullCowGame(); // constructor
    
    int32 GetMaxTries() const;
    int32 GetCurrentTry() const;
    int32 GetHiddenWordLength() const;
    
    bool IsGameWon() const;
    EGuessStatus CheckGuessValidity(FString) const;
    
    void Reset ();
    FBullCowCount SubmitValidGuess(FString);
    
    // Ignore for now
private:
    // see constructor for initialisation 
    int32 MyCurrentTry;
    FString MyHiddenWord;
    bool bGameIsWon;
    
    bool IsIsogram(FString) const;
    bool IsLowercase(FString Word) const;
};
